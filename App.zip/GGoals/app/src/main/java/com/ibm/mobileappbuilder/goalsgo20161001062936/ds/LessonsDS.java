

package com.ibm.mobileappbuilder.goalsgo20161001062936.ds;

import android.content.Context;

import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.restds.TypedByteArrayUtils;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * "LessonsDS" data source. (e37eb8dc-6eb2-4635-8592-5eb9696050e3)
 */
public class LessonsDS extends AppNowDatasource<LessonsDSItem>{

    // default page size
    private static final int PAGE_SIZE = 20;

    private LessonsDSService service;

    public static LessonsDS getInstance(SearchOptions searchOptions){
        return new LessonsDS(searchOptions);
    }

    private LessonsDS(SearchOptions searchOptions) {
        super(searchOptions);
        this.service = LessonsDSService.getInstance();
    }

    @Override
    public void getItem(String id, final Listener<LessonsDSItem> listener) {
        if ("0".equals(id)) {
                        getItems(new Listener<List<LessonsDSItem>>() {
                @Override
                public void onSuccess(List<LessonsDSItem> items) {
                    if(items != null && items.size() > 0) {
                        listener.onSuccess(items.get(0));
                    } else {
                        listener.onSuccess(new LessonsDSItem());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    listener.onFailure(e);
                }
            });
        } else {
                      service.getServiceProxy().getLessonsDSItemById(id, new Callback<LessonsDSItem>() {
                @Override
                public void success(LessonsDSItem result, Response response) {
                                        listener.onSuccess(result);
                }

                @Override
                public void failure(RetrofitError error) {
                                        listener.onFailure(error);
                }
            });
        }
    }

    @Override
    public void getItems(final Listener<List<LessonsDSItem>> listener) {
        getItems(0, listener);
    }

    @Override
    public void getItems(int pagenum, final Listener<List<LessonsDSItem>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        int skipNum = pagenum * PAGE_SIZE;
        String skip = skipNum == 0 ? null : String.valueOf(skipNum);
        String limit = PAGE_SIZE == 0 ? null: String.valueOf(PAGE_SIZE);
        String sort = getSort(searchOptions);
                service.getServiceProxy().queryLessonsDSItem(
                skip,
                limit,
                conditions,
                sort,
                null,
                null,
                new Callback<List<LessonsDSItem>>() {
            @Override
            public void success(List<LessonsDSItem> result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    private String[] getSearchableFields() {
        return new String[]{"name", "time", "description", "data"};
    }

    // Pagination

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getUniqueValuesFor(String searchStr, final Listener<List<String>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
                service.getServiceProxy().distinct(searchStr, conditions, new Callback<List<String>>() {
             @Override
             public void success(List<String> result, Response response) {
                                  result.removeAll(Collections.<String>singleton(null));
                 listener.onSuccess(result);
             }

             @Override
             public void failure(RetrofitError error) {
                                  listener.onFailure(error);
             }
        });
    }

    @Override
    public URL getImageUrl(String path) {
        return service.getImageUrl(path);
    }

    @Override
    public void create(LessonsDSItem item, Listener<LessonsDSItem> listener) {
                          service.getServiceProxy().createLessonsDSItem(item, callbackFor(listener));
          }

    private Callback<LessonsDSItem> callbackFor(final Listener<LessonsDSItem> listener) {
      return new Callback<LessonsDSItem>() {
          @Override
          public void success(LessonsDSItem item, Response response) {
                            listener.onSuccess(item);
          }

          @Override
          public void failure(RetrofitError error) {
                            listener.onFailure(error);
          }
      };
    }

    @Override
    public void updateItem(LessonsDSItem item, Listener<LessonsDSItem> listener) {
                          service.getServiceProxy().updateLessonsDSItem(item.getIdentifiableId(), item, callbackFor(listener));
          }

    @Override
    public void deleteItem(LessonsDSItem item, final Listener<LessonsDSItem> listener) {
                service.getServiceProxy().deleteLessonsDSItemById(item.getIdentifiableId(), new Callback<LessonsDSItem>() {
            @Override
            public void success(LessonsDSItem result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    @Override
    public void deleteItems(List<LessonsDSItem> items, final Listener<LessonsDSItem> listener) {
                service.getServiceProxy().deleteByIds(collectIds(items), new Callback<List<LessonsDSItem>>() {
            @Override
            public void success(List<LessonsDSItem> item, Response response) {
                                listener.onSuccess(null);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    protected List<String> collectIds(List<LessonsDSItem> items){
        List<String> ids = new ArrayList<>();
        for(LessonsDSItem item: items){
            ids.add(item.getIdentifiableId());
        }
        return ids;
    }

}

