
package com.ibm.mobileappbuilder.goalsgo20161001062936.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.goalsgo20161001062936.ds.AssignmentsDSService;
import com.ibm.mobileappbuilder.goalsgo20161001062936.presenters.LessonsDetailPresenter;
import com.ibm.mobileappbuilder.goalsgo20161001062936.R;
import ibmmobileappbuilder.behaviors.FabBehaviour;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.util.ColorUtils;
import ibmmobileappbuilder.util.Constants;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.goalsgo20161001062936.ds.AssignmentsDSItem;
import com.ibm.mobileappbuilder.goalsgo20161001062936.ds.AssignmentsDS;

public class LessonsDetailFragment extends ibmmobileappbuilder.ui.DetailFragment<AssignmentsDSItem>  {

    private CrudDatasource<AssignmentsDSItem> datasource;
    public static LessonsDetailFragment newInstance(Bundle args){
        LessonsDetailFragment fr = new LessonsDetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public LessonsDetailFragment(){
        super();
    }

    @Override
    public Datasource<AssignmentsDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = AssignmentsDS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        // the presenter for this view
        setPresenter(new LessonsDetailPresenter(
                (CrudDatasource) getDatasource(),
                this));
        // Edit button
        addBehavior(new FabBehaviour(this, R.drawable.ic_edit_white, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((DetailCrudPresenter<AssignmentsDSItem>) getPresenter()).editForm(getItem());
            }
        }));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.lessonsdetail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final AssignmentsDSItem item, View view) {
    }

    @Override
    protected void onShow(AssignmentsDSItem item) {
        // set the title for this fragment
        getActivity().setTitle(null);
    }

    @Override
    public void navigateToEditForm() {
        Bundle args = new Bundle();

        args.putInt(Constants.ITEMPOS, 0);
        args.putParcelable(Constants.CONTENT, getItem());
        args.putInt(Constants.MODE, Constants.MODE_EDIT);

        Intent intent = new Intent(getActivity(), AssignmentsDSItemFormActivity.class);
        intent.putExtras(args);
        startActivityForResult(intent, Constants.MODE_EDIT);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.delete_menu, menu);

        MenuItem item = menu.findItem(R.id.action_delete);
        ColorUtils.tintIcon(item, R.color.textBarColor, getActivity());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.action_delete){
            ((DetailCrudPresenter<AssignmentsDSItem>) getPresenter()).deleteItem(getItem());
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}

