
package com.ibm.mobileappbuilder.goalsgo20161001062936.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;

public interface LessonsDSServiceRest{

	@GET("/app/57ef5e0c57acb00300065c9c/r/lessonsDS")
	void queryLessonsDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<LessonsDSItem>> cb);

	@GET("/app/57ef5e0c57acb00300065c9c/r/lessonsDS/{id}")
	void getLessonsDSItemById(@Path("id") String id, Callback<LessonsDSItem> cb);

	@DELETE("/app/57ef5e0c57acb00300065c9c/r/lessonsDS/{id}")
  void deleteLessonsDSItemById(@Path("id") String id, Callback<LessonsDSItem> cb);

  @POST("/app/57ef5e0c57acb00300065c9c/r/lessonsDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<LessonsDSItem>> cb);

  @POST("/app/57ef5e0c57acb00300065c9c/r/lessonsDS")
  void createLessonsDSItem(@Body LessonsDSItem item, Callback<LessonsDSItem> cb);

  @PUT("/app/57ef5e0c57acb00300065c9c/r/lessonsDS/{id}")
  void updateLessonsDSItem(@Path("id") String id, @Body LessonsDSItem item, Callback<LessonsDSItem> cb);

  @GET("/app/57ef5e0c57acb00300065c9c/r/lessonsDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
}

