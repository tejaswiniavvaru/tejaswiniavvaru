
package com.ibm.mobileappbuilder.goalsgo20161001062936.presenters;

import com.ibm.mobileappbuilder.goalsgo20161001062936.R;
import com.ibm.mobileappbuilder.goalsgo20161001062936.ds.AssignmentsDSItem;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.mvp.view.DetailView;

public class LessonsDetailPresenter extends BasePresenter implements DetailCrudPresenter<AssignmentsDSItem>,
      Datasource.Listener<AssignmentsDSItem> {

    private final CrudDatasource<AssignmentsDSItem> datasource;
    private final DetailView view;

    public LessonsDetailPresenter(CrudDatasource<AssignmentsDSItem> datasource, DetailView view){
        this.datasource = datasource;
        this.view = view;
    }

    @Override
    public void deleteItem(AssignmentsDSItem item) {
        datasource.deleteItem(item, this);
    }

    @Override
    public void editForm(AssignmentsDSItem item) {
        view.navigateToEditForm();
    }

    @Override
    public void onSuccess(AssignmentsDSItem item) {
                view.showMessage(R.string.item_deleted, true);
        view.close(true);
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic, true);
    }
}

