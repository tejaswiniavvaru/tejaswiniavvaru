package com.ibm.mobileappbuilder.goalsgo20161001062936.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.goalsgo20161001062936.ds.AssignmentsDSService;
import com.ibm.mobileappbuilder.goalsgo20161001062936.presenters.LessonsPresenter;
import com.ibm.mobileappbuilder.goalsgo20161001062936.R;
import ibmmobileappbuilder.behaviors.FabBehaviour;
import ibmmobileappbuilder.behaviors.SelectionBehavior;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ui.ListGridFragment;
import ibmmobileappbuilder.util.Constants;
import ibmmobileappbuilder.util.ViewHolder;
import java.util.List;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.goalsgo20161001062936.ds.AssignmentsDSItem;
import com.ibm.mobileappbuilder.goalsgo20161001062936.ds.AssignmentsDS;
import ibmmobileappbuilder.mvp.view.CrudListView;
import ibmmobileappbuilder.ds.CrudDatasource;
import android.content.Intent;
import ibmmobileappbuilder.util.Constants;

import static ibmmobileappbuilder.util.NavigationUtils.generateIntentToAddOrUpdateItem;

/**
 * "LessonsFragment" listing
 */
public class LessonsFragment extends ListGridFragment<AssignmentsDSItem> implements CrudListView<AssignmentsDSItem> {

    private CrudDatasource<AssignmentsDSItem> datasource;

    // "Add" button
    private FabBehaviour fabBehavior;

    public static LessonsFragment newInstance(Bundle args) {
        LessonsFragment fr = new LessonsFragment();

        fr.setArguments(args);
        return fr;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setPresenter(new LessonsPresenter(
            (CrudDatasource) getDatasource(),
            this
        ));
        // Multiple selection
        SelectionBehavior<AssignmentsDSItem> selectionBehavior = new SelectionBehavior<>(
            this,
            R.string.remove_items,
            R.drawable.ic_delete_alpha);

        selectionBehavior.setCallback(new SelectionBehavior.Callback<AssignmentsDSItem>() {
            @Override
            public void onSelected(List<AssignmentsDSItem> selectedItems) {
                getPresenter().deleteItems(selectedItems);
            }
        });
        addBehavior(selectionBehavior);
        // FAB button
        fabBehavior = new FabBehaviour(this, R.drawable.ic_add_white, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getPresenter().addForm();
            }
        });
        addBehavior(fabBehavior);
    }

    protected SearchOptions getSearchOptions() {
      SearchOptions.Builder searchOptionsBuilder = SearchOptions.Builder.searchOptions();
      return searchOptionsBuilder.build();
    }


    /**
    * Layout for the list itselft
    */
    @Override
    protected int getLayout() {
        return R.layout.fragment_list;
    }

    /**
    * Layout for each element in the list
    */
    @Override
    protected int getItemLayout() {
        return R.layout.lessons_item;
    }

    @Override
    protected Datasource<AssignmentsDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
      datasource = AssignmentsDS.getInstance(getSearchOptions());
      return datasource;
    }

    @Override
    protected void bindView(AssignmentsDSItem item, View view, int position) {
        
        TextView title = ViewHolder.get(view, R.id.title);
        
        title.setText("apple");
        
    }

    @Override
    protected void itemClicked(final AssignmentsDSItem item, final int position) {
        fabBehavior.hide(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                getPresenter().detail(item, position);
            }
        });
    }

    @Override
    public void showDetail(AssignmentsDSItem item, int position) {
        Bundle args = new Bundle();
        args.putInt(Constants.ITEMPOS, position);
        args.putParcelable(Constants.CONTENT, item);
        Intent intent = new Intent(getActivity(), LessonsDetailActivity.class);
        intent.putExtras(args);

        if (!getResources().getBoolean(R.bool.tabletLayout)) {
            startActivityForResult(intent, Constants.DETAIL);
        } else {
            startActivity(intent);
        }
    }

    @Override
    public void showAdd() {
        startActivityForResult(generateIntentToAddOrUpdateItem(null,
                        0,
                        getActivity(),
                        AssignmentsDSItemFormActivity.class
                ), Constants.MODE_CREATE
        );
    }

    @Override
    public void showEdit(AssignmentsDSItem item, int position) {
    startActivityForResult(
                generateIntentToAddOrUpdateItem(item,
                        position,
                        getActivity(),
                        AssignmentsDSItemFormActivity.class
                ), Constants.MODE_EDIT
        );
    }
}

