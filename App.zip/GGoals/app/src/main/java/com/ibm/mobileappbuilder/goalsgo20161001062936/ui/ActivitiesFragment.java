

package com.ibm.mobileappbuilder.goalsgo20161001062936.ui;

import android.os.Bundle;

import com.ibm.mobileappbuilder.goalsgo20161001062936.R;

import java.util.ArrayList;
import java.util.List;

import ibmmobileappbuilder.MenuItem;

import ibmmobileappbuilder.actions.StartActivityAction;
import ibmmobileappbuilder.util.Constants;

/**
 * ActivitiesFragment menu fragment.
 */
public class ActivitiesFragment extends ibmmobileappbuilder.ui.MenuFragment {

    /**
     * Default constructor
     */
    public ActivitiesFragment(){
        super();
    }

    // Factory method
    public static ActivitiesFragment newInstance(Bundle args) {
        ActivitiesFragment fragment = new ActivitiesFragment();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
      public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
                }

    // Menu Fragment interface
    @Override
    public List<MenuItem> getMenuItems() {
        ArrayList<MenuItem> items = new ArrayList<MenuItem>();
        items.add(new MenuItem()
            .setLabel("lessons")
            .setIcon(R.drawable.png_studyicon211)
            .setAction(new StartActivityAction(LessonsActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("assignments")
            .setIcon(R.drawable.jpg_images1330)
            .setAction(new StartActivityAction(AssignmentsActivity.class, Constants.DETAIL))
        );
        return items;
    }

    @Override
    public int getLayout() {
        return R.layout.fragment_grid;
    }

    @Override
    public int getItemLayout() {
        return R.layout.activities_item;
    }
}

