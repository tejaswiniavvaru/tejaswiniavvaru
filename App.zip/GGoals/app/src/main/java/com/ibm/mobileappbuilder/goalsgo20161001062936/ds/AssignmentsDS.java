

package com.ibm.mobileappbuilder.goalsgo20161001062936.ds;

import android.content.Context;

import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.restds.TypedByteArrayUtils;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * "AssignmentsDS" data source. (e37eb8dc-6eb2-4635-8592-5eb9696050e3)
 */
public class AssignmentsDS extends AppNowDatasource<AssignmentsDSItem>{

    // default page size
    private static final int PAGE_SIZE = 20;

    private AssignmentsDSService service;

    public static AssignmentsDS getInstance(SearchOptions searchOptions){
        return new AssignmentsDS(searchOptions);
    }

    private AssignmentsDS(SearchOptions searchOptions) {
        super(searchOptions);
        this.service = AssignmentsDSService.getInstance();
    }

    @Override
    public void getItem(String id, final Listener<AssignmentsDSItem> listener) {
        if ("0".equals(id)) {
                        getItems(new Listener<List<AssignmentsDSItem>>() {
                @Override
                public void onSuccess(List<AssignmentsDSItem> items) {
                    if(items != null && items.size() > 0) {
                        listener.onSuccess(items.get(0));
                    } else {
                        listener.onSuccess(new AssignmentsDSItem());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    listener.onFailure(e);
                }
            });
        } else {
                      service.getServiceProxy().getAssignmentsDSItemById(id, new Callback<AssignmentsDSItem>() {
                @Override
                public void success(AssignmentsDSItem result, Response response) {
                                        listener.onSuccess(result);
                }

                @Override
                public void failure(RetrofitError error) {
                                        listener.onFailure(error);
                }
            });
        }
    }

    @Override
    public void getItems(final Listener<List<AssignmentsDSItem>> listener) {
        getItems(0, listener);
    }

    @Override
    public void getItems(int pagenum, final Listener<List<AssignmentsDSItem>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        int skipNum = pagenum * PAGE_SIZE;
        String skip = skipNum == 0 ? null : String.valueOf(skipNum);
        String limit = PAGE_SIZE == 0 ? null: String.valueOf(PAGE_SIZE);
        String sort = getSort(searchOptions);
                service.getServiceProxy().queryAssignmentsDSItem(
                skip,
                limit,
                conditions,
                sort,
                null,
                null,
                new Callback<List<AssignmentsDSItem>>() {
            @Override
            public void success(List<AssignmentsDSItem> result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    private String[] getSearchableFields() {
        return new String[]{null};
    }

    // Pagination

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getUniqueValuesFor(String searchStr, final Listener<List<String>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
                service.getServiceProxy().distinct(searchStr, conditions, new Callback<List<String>>() {
             @Override
             public void success(List<String> result, Response response) {
                                  result.removeAll(Collections.<String>singleton(null));
                 listener.onSuccess(result);
             }

             @Override
             public void failure(RetrofitError error) {
                                  listener.onFailure(error);
             }
        });
    }

    @Override
    public URL getImageUrl(String path) {
        return service.getImageUrl(path);
    }

    @Override
    public void create(AssignmentsDSItem item, Listener<AssignmentsDSItem> listener) {
                    
        if(item.appleUri != null ||
        item.phasesUri != null){
            service.getServiceProxy().createAssignmentsDSItem(item,
                TypedByteArrayUtils.fromUri(item.appleUri),
                TypedByteArrayUtils.fromUri(item.phasesUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().createAssignmentsDSItem(item, callbackFor(listener));
        
    }

    private Callback<AssignmentsDSItem> callbackFor(final Listener<AssignmentsDSItem> listener) {
      return new Callback<AssignmentsDSItem>() {
          @Override
          public void success(AssignmentsDSItem item, Response response) {
                            listener.onSuccess(item);
          }

          @Override
          public void failure(RetrofitError error) {
                            listener.onFailure(error);
          }
      };
    }

    @Override
    public void updateItem(AssignmentsDSItem item, Listener<AssignmentsDSItem> listener) {
                    
        if(item.appleUri != null ||
        item.phasesUri != null){
            service.getServiceProxy().updateAssignmentsDSItem(item.getIdentifiableId(),
                item,
                TypedByteArrayUtils.fromUri(item.appleUri),
                TypedByteArrayUtils.fromUri(item.phasesUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().updateAssignmentsDSItem(item.getIdentifiableId(), item, callbackFor(listener));
        
    }

    @Override
    public void deleteItem(AssignmentsDSItem item, final Listener<AssignmentsDSItem> listener) {
                service.getServiceProxy().deleteAssignmentsDSItemById(item.getIdentifiableId(), new Callback<AssignmentsDSItem>() {
            @Override
            public void success(AssignmentsDSItem result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    @Override
    public void deleteItems(List<AssignmentsDSItem> items, final Listener<AssignmentsDSItem> listener) {
                service.getServiceProxy().deleteByIds(collectIds(items), new Callback<List<AssignmentsDSItem>>() {
            @Override
            public void success(List<AssignmentsDSItem> item, Response response) {
                                listener.onSuccess(null);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    protected List<String> collectIds(List<AssignmentsDSItem> items){
        List<String> ids = new ArrayList<>();
        for(AssignmentsDSItem item: items){
            ids.add(item.getIdentifiableId());
        }
        return ids;
    }

}

