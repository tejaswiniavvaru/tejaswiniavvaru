
package com.ibm.mobileappbuilder.goalsgo20161001062936.ds;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class LessonsDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("name") public String name;
    @SerializedName("time") public String time;
    @SerializedName("description") public String description;
    @SerializedName("data") public String data;
    @SerializedName("id") public String id;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(time);
        dest.writeString(description);
        dest.writeString(data);
        dest.writeString(id);
    }

    public static final Creator<LessonsDSItem> CREATOR = new Creator<LessonsDSItem>() {
        @Override
        public LessonsDSItem createFromParcel(Parcel in) {
            LessonsDSItem item = new LessonsDSItem();

            item.name = in.readString();
            item.time = in.readString();
            item.description = in.readString();
            item.data = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public LessonsDSItem[] newArray(int size) {
            return new LessonsDSItem[size];
        }
    };

}


