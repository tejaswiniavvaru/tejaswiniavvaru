
package com.ibm.mobileappbuilder.goalsgo20161001062936.ds;
import android.graphics.Bitmap;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.Uri;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class AssignmentsDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("apple") public String apple;
    @SerializedName("phases") public String phases;
    @SerializedName("id") public String id;
    @SerializedName("appleUri") public transient Uri appleUri;
    @SerializedName("phasesUri") public transient Uri phasesUri;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(apple);
        dest.writeString(phases);
        dest.writeString(id);
    }

    public static final Creator<AssignmentsDSItem> CREATOR = new Creator<AssignmentsDSItem>() {
        @Override
        public AssignmentsDSItem createFromParcel(Parcel in) {
            AssignmentsDSItem item = new AssignmentsDSItem();

            item.apple = in.readString();
            item.phases = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public AssignmentsDSItem[] newArray(int size) {
            return new AssignmentsDSItem[size];
        }
    };

}


