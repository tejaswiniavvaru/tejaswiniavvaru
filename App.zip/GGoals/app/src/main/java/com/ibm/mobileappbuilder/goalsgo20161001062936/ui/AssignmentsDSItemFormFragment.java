
package com.ibm.mobileappbuilder.goalsgo20161001062936.ui;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import com.ibm.mobileappbuilder.goalsgo20161001062936.ds.AssignmentsDSItem;
import com.ibm.mobileappbuilder.goalsgo20161001062936.ds.AssignmentsDSService;
import com.ibm.mobileappbuilder.goalsgo20161001062936.presenters.LessonsFormPresenter;
import com.ibm.mobileappbuilder.goalsgo20161001062936.R;
import ibmmobileappbuilder.ui.FormFragment;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.views.ImagePicker;
import java.io.IOException;
import java.io.File;

import static android.net.Uri.fromFile;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.goalsgo20161001062936.ds.AssignmentsDSItem;
import com.ibm.mobileappbuilder.goalsgo20161001062936.ds.AssignmentsDS;

public class AssignmentsDSItemFormFragment extends FormFragment<AssignmentsDSItem> {

    private CrudDatasource<AssignmentsDSItem> datasource;

    public static AssignmentsDSItemFormFragment newInstance(Bundle args){
        AssignmentsDSItemFormFragment fr = new AssignmentsDSItemFormFragment();
        fr.setArguments(args);

        return fr;
    }

    public AssignmentsDSItemFormFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        // the presenter for this view
        setPresenter(new LessonsFormPresenter(
                (CrudDatasource) getDatasource(),
                this));

            }

    @Override
    protected AssignmentsDSItem newItem() {
        return new AssignmentsDSItem();
    }

    private AssignmentsDSService getRestService(){
        return AssignmentsDSService.getInstance();
    }

    @Override
    protected int getLayout() {
        return R.layout.lessons_form;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final AssignmentsDSItem item, View view) {
        
        bindImage(R.id.assignmentsds_apple,
            item.apple != null ?
                getRestService().getImageUrl(item.apple) : null,
            0,
            new ImagePicker.Callback(){
                @Override
                public void imageRemoved(){
                    item.apple = null;
                    item.appleUri = null;
                    ((ImagePicker) getView().findViewById(R.id.assignmentsds_apple)).clear();
                }
            }
        );
        
        
        bindImage(R.id.assignmentsds_phases,
            item.phases != null ?
                getRestService().getImageUrl(item.phases) : null,
            1,
            new ImagePicker.Callback(){
                @Override
                public void imageRemoved(){
                    item.phases = null;
                    item.phasesUri = null;
                    ((ImagePicker) getView().findViewById(R.id.assignmentsds_phases)).clear();
                }
            }
        );
        
    }

    @Override
    public Datasource<AssignmentsDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = AssignmentsDS.getInstance(new SearchOptions());
        return datasource;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == Activity.RESULT_OK) {
            ImagePicker picker = null;
            Uri imageUri = null;
            AssignmentsDSItem item = getItem();

            if((requestCode & ImagePicker.GALLERY_REQUEST_CODE) == ImagePicker.GALLERY_REQUEST_CODE) {
              imageUri = data.getData();
              switch (requestCode - ImagePicker.GALLERY_REQUEST_CODE) {
                        
                        case 0:   // apple field
                            item.appleUri = imageUri;
                            item.apple = "cid:apple";
                            picker = (ImagePicker) getView().findViewById(R.id.assignmentsds_apple);
                            break;
                        
                        
                        case 1:   // phases field
                            item.phasesUri = imageUri;
                            item.phases = "cid:phases";
                            picker = (ImagePicker) getView().findViewById(R.id.assignmentsds_phases);
                            break;
                        
                default:
                  return;
              }

              picker.setImageUri(imageUri);
            } else if((requestCode & ImagePicker.CAPTURE_REQUEST_CODE) == ImagePicker.CAPTURE_REQUEST_CODE) {
				      switch (requestCode - ImagePicker.CAPTURE_REQUEST_CODE) {
                        
                        case 0:   // apple field
                            picker = (ImagePicker) getView().findViewById(R.id.assignmentsds_apple);
                            imageUri = fromFile(picker.getImageFile());
                        		item.appleUri = imageUri;
                            item.apple = "cid:apple";
                            break;
                        
                        
                        case 1:   // phases field
                            picker = (ImagePicker) getView().findViewById(R.id.assignmentsds_phases);
                            imageUri = fromFile(picker.getImageFile());
                        		item.phasesUri = imageUri;
                            item.phases = "cid:phases";
                            break;
                        
                default:
                  return;
              }
              picker.setImageUri(imageUri);
            }
        }
    }
}

