
package com.ibm.mobileappbuilder.goalsgo20161001062936.ds;
import java.net.URL;
import com.ibm.mobileappbuilder.goalsgo20161001062936.R;
import ibmmobileappbuilder.ds.RestService;
import ibmmobileappbuilder.util.StringUtils;

/**
 * "AssignmentsDSService" REST Service implementation
 */
public class AssignmentsDSService extends RestService<AssignmentsDSServiceRest>{

    public static AssignmentsDSService getInstance(){
          return new AssignmentsDSService();
    }

    private AssignmentsDSService() {
        super(AssignmentsDSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://ibm-pods.buildup.io";
    }

    @Override
    protected String getApiKey() {
        return "fR8sZ4Xy";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://ibm-pods.buildup.io/app/57ef5e0c57acb00300065c9c",
                path,
                "apikey=fR8sZ4Xy");
    }

}

