
package com.ibm.mobileappbuilder.goalsgo20161001062936.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface AssignmentsDSServiceRest{

	@GET("/app/57ef5e0c57acb00300065c9c/r/assignmentsDS")
	void queryAssignmentsDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<AssignmentsDSItem>> cb);

	@GET("/app/57ef5e0c57acb00300065c9c/r/assignmentsDS/{id}")
	void getAssignmentsDSItemById(@Path("id") String id, Callback<AssignmentsDSItem> cb);

	@DELETE("/app/57ef5e0c57acb00300065c9c/r/assignmentsDS/{id}")
  void deleteAssignmentsDSItemById(@Path("id") String id, Callback<AssignmentsDSItem> cb);

  @POST("/app/57ef5e0c57acb00300065c9c/r/assignmentsDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<AssignmentsDSItem>> cb);

  @POST("/app/57ef5e0c57acb00300065c9c/r/assignmentsDS")
  void createAssignmentsDSItem(@Body AssignmentsDSItem item, Callback<AssignmentsDSItem> cb);

  @PUT("/app/57ef5e0c57acb00300065c9c/r/assignmentsDS/{id}")
  void updateAssignmentsDSItem(@Path("id") String id, @Body AssignmentsDSItem item, Callback<AssignmentsDSItem> cb);

  @GET("/app/57ef5e0c57acb00300065c9c/r/assignmentsDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef5e0c57acb00300065c9c/r/assignmentsDS")
    void createAssignmentsDSItem(
        @Part("data") AssignmentsDSItem item,
        @Part("apple") TypedByteArray apple,
    @Part("phases") TypedByteArray phases,
        Callback<AssignmentsDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef5e0c57acb00300065c9c/r/assignmentsDS/{id}")
    void updateAssignmentsDSItem(
        @Path("id") String id,
        @Part("data") AssignmentsDSItem item,
        @Part("apple") TypedByteArray apple,
    @Part("phases") TypedByteArray phases,
        Callback<AssignmentsDSItem> cb);
}

